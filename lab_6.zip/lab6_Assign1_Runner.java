package com.company;
class Calculator {
    public static int sum(int num1, int num2) {
        int sum = num1 + num2;
        return sum;
    }

    public static int multiply(int num1, int num2)
    {
        return num1 * num2;

    }

    public static int divide(int num1, int num2)
    {
        return num1 / num2;
    }

    public static int modulus(int num1, int num2)
    {
        return num1 % num2;
    }

    public static double sin(int num)
    {
        return Math.sin(num);

    }

    public static double cos(int num)
    {
        return Math.cos(num);
    }

    public static double tan(int num)
    {
        return Math.tan(num);
    }
}
class Lab6_Assign1_Runner {
    public static void main(String[] args){
        System.out.println(Calculator.sum(14,16));
        System.out.println(Calculator.multiply(39,72));
        System.out.println(Calculator.divide(42,2));
        System.out.println(Calculator.modulus(131,565));
        System.out.println(Calculator.sin(90));
        System.out.println(Calculator.cos(270));
        System.out.println(Calculator.tan(300));

    }
}

